const express = require('express');
const router = express.Router();
const penggunaController = require('../controllers/penggunaController');

// GETsemua pengguna
router.get('/', penggunaController.getSemuaPengguna);

// POST pengguna baru
router.post('/', penggunaController.tambahPengguna);

module.exports = router;