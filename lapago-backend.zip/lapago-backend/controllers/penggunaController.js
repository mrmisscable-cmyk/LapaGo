const db = require('../config/db');

// 1. Mengambil semua data pengguna
const getSemuaPengguna = (req, res) => {
    const query = 'SELECT * FROM pengguna';
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error saat mengambil data pengguna:', err);
            return res.status(500).json({ status: 500, pesan: 'Terjadi kesalahan pada server' });
        }
        
        res.status(200).json({
            status: 200,
            pesan: 'Data pengguna berhasil diambil',
            data: results
        });
    });
};

// 2. Menambah data pengguna baru (Register)
const tambahPengguna = (req, res) => {
    const { nama, email, no_hp, kata_sandi, peran } = req.body;

    // Validasi input sederhana
    if (!nama || !email || !kata_sandi) {
        return res.status(400).json({
            status: 400,
            pesan: 'Nama, email, dan kata sandi wajib diisi'
        });
    }

    const query = 'INSERT INTO pengguna (nama, email, no_hp, kata_sandi, peran) VALUES (?, ?, ?, ?, ?)';
    const values = [nama, email, no_hp || null, kata_sandi, peran || 'Pelanggan'];

    db.query(query, values, (err, results) => {
        if (err) {
            console.error('Error saat menambah pengguna:', err);
            return res.status(500).json({ status: 500, pesan: 'Gagal menambah data pengguna' });
        }

        res.status(201).json({
            status: 201,
            pesan: 'Pengguna berhasil ditambahkan',
            data: {
                id_user: results.insertId,
                nama,
                email,
                no_hp,
                peran: peran || 'Pelanggan'
            }
        });
    });
};

module.exports = {
    getSemuaPengguna,
    tambahPengguna
};